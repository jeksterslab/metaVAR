library(testthat)
library(metaVAR)

test_check("metaVAR")
