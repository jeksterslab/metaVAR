.FitCTVARLambda <- function(p) {
  # C
  # measurement model factor loadings
  return(
    .FitDTVARLambda(p = p)
  )
}
