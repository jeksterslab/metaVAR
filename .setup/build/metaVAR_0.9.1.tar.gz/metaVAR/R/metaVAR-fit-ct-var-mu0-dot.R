.FitCTVARMu0 <- function(p) {
  # x0
  # initial condition
  # mean
  return(
    .FitDTVARMu0(p = p)
  )
}
