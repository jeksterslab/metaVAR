.FitCTVARKappa <- function(p) {
  # D
  # observed variables on covariates
  return(
    .FitDTVARKappa(p = p)
  )
}
