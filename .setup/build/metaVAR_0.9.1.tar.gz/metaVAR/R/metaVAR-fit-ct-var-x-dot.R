.FitCTVARX <- function() {
  # u
  # covariates
  return(
    .FitDTVARX()
  )
}
