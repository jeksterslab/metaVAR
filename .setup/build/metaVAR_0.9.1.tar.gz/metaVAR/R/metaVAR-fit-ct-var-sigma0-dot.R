.FitCTVARSigma0 <- function(p) {
  # R0
  # initial condition
  # covariance
  return(
    .FitDTVARSigma0(p = p)
  )
}
