#' Fit Multivariate Meta-Analysis
#'
#' This function estimates the mean and covariance matrix
#' of a vector of coefficients
#' using the estimated coefficients and sampling variance-covariance matrix
#' from each individual.
#'
#' @details For \eqn{i = \left\{1, \cdots, n \right\}},
#'   the objective function used to estimate the mean \eqn{\boldsymbol{\mu}}
#'   and covariance matrix \eqn{\boldsymbol{\Sigma}}
#'   of the random coefficients \eqn{\mathbf{y}_{i}} is given by
#'   \deqn{
#'     \ell
#'     \left(
#'     \boldsymbol{\mu} ,
#'     \boldsymbol{\Sigma} \mid \mathbf{y}_{i},
#'     \mathbb{V} \left( \mathbf{y}_{i} \right)
#'     \right)
#'     =
#'     - \frac{1}{2}
#'     \left[
#'     q \log \left( 2 \pi \right)
#'     +
#'     \log
#'     \left(
#'     \left|
#'       \mathbb{V} \left( \mathbf{y}_{i} \right) - \boldsymbol{\Sigma}
#'     \right|
#'     \right)
#'     +
#'     \left( \mathbf{y}_{i} - \boldsymbol{\mu} \right)^{\prime}
#'     \left(
#'       \mathbb{V} \left( \mathbf{y}_{i} \right) - \boldsymbol{\Sigma}
#'     \right)^{-1}
#'     \left( \mathbf{y}_{i} - \boldsymbol{\mu} \right)
#'     \right]
#'   }
#'  where
#'  \eqn{q} is the number of unique elements
#'  in \eqn{\boldsymbol{\mu}} and \eqn{\boldsymbol{\Sigma}}, and
#'  \eqn{\mathbb{V} \left( \mathbf{y}_{i} \right)}
#'  is the sampling variance-covariance matrix of \eqn{\mathbf{y}_{i}}.
#'
#' @author Ivan Jacob Agaloos Pesigan
#'
#' @param y A list.
#'   Each element of the list is a numeric vector
#'   of estimated coefficients.
#' @param v A list.
#'   Each element of the list
#'   is a sampling variance-covariance matrix of `y`.
#' @param mu_start Numeric vector.
#'   Optional vector of starting values for `mu`.
#' @param mu_lbound Numeric vector.
#'   Optional vector of lower bound values for `mu`.
#' @param mu_ubound Numeric vector.
#'   Optional vector of upper bound values for `mu`.
#' @param sigma_l_start Numeric matrix.
#'   Optional matrix of starting values for `t(chol(sigma))`.
#' @param sigma_l_lbound Numeric matrix.
#'   Optional matrix of lower bound values for `t(chol(sigma))`.
#' @param sigma_l_ubound Numeric matrix.
#'   Optional matrix of upper bound values for `t(chol(sigma))`.
#' @param try Positive integer.
#'   Number of extra optimization tries.
#' @param ncores Positive integer.
#'   Number of cores to use.
#'
#' @family Meta-Analysis of VAR Functions
#' @keywords metaVAR meta
#' @import OpenMx
#' @importFrom stats coef vcov
#' @export
Meta <- function(y,
                 v,
                 mu_start = NULL,
                 mu_lbound = NULL,
                 mu_ubound = NULL,
                 sigma_l_start = NULL,
                 sigma_l_lbound = NULL,
                 sigma_l_ubound = NULL,
                 try = 1000,
                 ncores = NULL) {
  n <- length(y)
  p <- length(y[[1]])
  args <- list(
    y = y,
    v = v,
    n = n,
    p = p,
    mu_start = mu_start,
    mu_lbound = mu_lbound,
    mu_ubound = mu_ubound,
    sigma_l_start = sigma_l_start,
    sigma_l_lbound = sigma_l_lbound,
    sigma_l_ubound = sigma_l_ubound,
    try = try,
    ncores = ncores
  )
  output <- .MetaGeneric(
    y = y,
    v = v,
    n = n,
    p = p,
    mu_start = mu_start,
    mu_lbound = mu_lbound,
    mu_ubound = mu_ubound,
    sigma_l_start = sigma_l_start,
    sigma_l_lbound = sigma_l_lbound,
    sigma_l_ubound = sigma_l_ubound,
    try = try,
    ncores = ncores
  )
  out <- list(
    call = match.call(),
    args = args,
    fun = "Meta",
    output = output,
    transform = .Transform(
      coef = coef(output),
      vcov = vcov(output),
      p = p
    )
  )
  class(out) <- c(
    "metavarmeta",
    class(out)
  )
  return(out)
}
