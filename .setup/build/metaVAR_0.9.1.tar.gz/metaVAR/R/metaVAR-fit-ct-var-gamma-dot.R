.FitCTVARGamma <- function(p) {
  # B
  # latent variables on covariates
  return(
    .FitDTVARGamma(p = p)
  )
}
